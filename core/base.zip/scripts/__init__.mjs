import { readFileSync } from "fs";
import string from "../devtool/string.mjs";

const packageJsonContent = readFileSync("./package.json", "utf-8");
const packageJson = JSON.parse(packageJsonContent);
const packageName = packageJson.name;

export default packageName;

export const projectTitle = string.upper(packageName);
