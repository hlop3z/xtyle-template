import fs from "fs";
import { execSync } from "child_process";
import ProjectName from "./__init__.mjs";

const sourceCSS = "dist/style.css";
const destinationCSS = `dist/${ProjectName}.min.css`;
const moduleJS = `dist/index.min.js`;
const destinationJS = `dist/bundle.min.js`;

try {
  fs.copyFileSync(sourceCSS, destinationCSS);
} catch (error) {
  console.error("Error executing command:", error.message);
}
try {
  const fileCSS = fs.readFileSync(destinationCSS, "utf-8");
  const fileJS = fs.readFileSync(moduleJS, "utf-8");

  // Code
  let codeOut = fileJS;
  codeOut += `xtyle.util.inject(${
    "`" + fileCSS.trim() + "`"
  }, "${ProjectName}-plugin")`;

  // File
  fs.writeFile(destinationJS, codeOut, (err) => {
    if (err) {
      console.error("Error writing to file:", err);
    } else {
      console.log("Data written to file successfully");
    }
  });
} catch (error) {
  console.error("Error executing command:", error.message);
}

try {
  const result = execSync("rm dist/vite.svg");
  console.log(result.toString());
} catch (error) {
  console.error("Error executing command:", error.message);
}
