import fs from "fs";
import ProjectName from "./__init__.mjs";

const CORE_DIR = `../../plugins/${ProjectName}`;
const plugin = (file) => `${CORE_DIR}/${file}`;

const FILE = {
  /*
  css: {
    in: "dist/style.css",
    out: plugin("index.css"),
  },
  */
  js: {
    in: "dist/bundle.min.js",
    out: plugin("index.min.js"),
  },
  types: {
    in: "dist/index.d.ts",
    out: plugin("index.d.ts"),
  },
};

// Create Directory
if (!fs.existsSync(CORE_DIR)) {
  fs.mkdirSync(CORE_DIR, { recursive: true });
}

try {
  Object.keys(FILE).forEach((key) => {
    fs.copyFileSync(FILE[key].in, FILE[key].out);
  });
} catch (error) {
  console.error("Error executing command:", error.message);
}
