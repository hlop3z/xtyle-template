// rollup.config.js
import fs from "fs";
import terser from "@rollup/plugin-terser";
import { projectTitle } from "./scripts/__init__.mjs";

// Read the package.json
const pkg = JSON.parse(fs.readFileSync("./package.json", "utf-8"));

export default {
  input: "dist/index.js",
  output: {
    file: `dist/index.min.js`,
    format: "iife",
    name: projectTitle,
    plugins: [terser()],
  },
};
