//@ts-nocheck

/* Library */
import * as Components from "./components/index.ts";
import Directives from "./app/directives.ts";
import Routes from "./app/routes.ts";

/* TypeScript */
export * from "./components/index.ts";
export { default as directives } from "./app/directives.ts";

/* Browser Install */
export const install = {
  routes: Routes,
  elements: xtyle.build(Components, packageName),
  directives: Directives,
};
