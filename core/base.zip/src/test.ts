//@ts-nocheck
import Preview from "./preview.tsx";
import { install } from "./index.ts";

/**
 * @Register <Plugin>
 */
xtyle.use(install);

/**
 * @Router
 */
const router = {
  history: false,
  baseURL: null,
};

/**
 * @Render
 */
xtyle.init(DemoApp, document.body, router);

/**
 * @Preview
 */

/* Globals */
console.log("Globals: ", xtyle.global);

/* Store */
console.log("Store: ", xtyle.store);

/* Routes */
console.log("Routes: ", Object.keys(xtyle.router.routes));

/* Directives Keys */
console.log("Directives: ", Object.keys(xtyle.allDirectives));

/* Components Keys */
console.log("Components: ", Object.keys(xtyle.allComponents));
