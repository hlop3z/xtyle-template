// Router Name
import packageName from "./name";

// Admin
export const router = (path: string, query?: any) =>
  xtyle.router.go(`${packageName}/${path}`, query);

// Patterns
export default [
  `/${packageName}/{?view}`,
  `/${packageName}/{view}/{tab}`,
  `/${packageName}/{view}/{tab}/{section}`,
];
