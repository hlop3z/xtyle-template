//@ts-nocheck

const NAME = packageName;

export default NAME;
