import Props from "./props.ts";
import style from "./style.module.scss";
// import "./style.scss";

export default function Component(props: Props = {}) {
  const className: string = "icon";
  return (
    <div x-html {...props} class={[className, props.class, style.base]}>
      {props.children}
    </div>
  );
}
