/// <reference types="../../node_modules/xtyle/dist/index.d.ts" />

declare const preact: any;
declare const h: any;
